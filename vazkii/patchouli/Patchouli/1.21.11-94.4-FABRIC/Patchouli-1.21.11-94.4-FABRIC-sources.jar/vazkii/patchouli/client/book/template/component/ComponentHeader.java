package vazkii.patchouli.client.book.template.component;

import com.google.gson.annotations.SerializedName;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.client.book.BookContentsBuilder;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.BookPage;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.template.TemplateComponent;

import java.util.function.UnaryOperator;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7225;

public class ComponentHeader extends TemplateComponent {

	public IVariable text;

	@SerializedName("color") public IVariable colorStr;

	boolean centered = true;
	float scale = 1F;

	transient class_2561 actualText;
	transient int color;

	@Override
	public void build(BookContentsBuilder builder, BookPage page, BookEntry entry, int pageNum) {
		try {
			color = Integer.parseInt(colorStr.asString(""), 16);
			// 6 位 hex 颜色（如 "000000"/"777777"）解析后 alpha 字节为 0。1.21.1 的 Font 会把
			// alpha=0 兜底成不透明，1.21.11 删了该兜底 → 文字全透明。此处补齐不透明 alpha。
			if ((color & 0xFF000000) == 0) {
				color |= 0xFF000000;
			}
		} catch (NumberFormatException e) {
			color = page.book.headerColor;
		}

		if (x == -1) {
			x = GuiBook.PAGE_WIDTH / 2;
		}
		if (y == -1) {
			y = 0;
		}
	}

	@Override
	public void render(class_332 graphics, BookPage page, int mouseX, int mouseY, float pticks) {
		graphics.method_51448().pushMatrix();
		graphics.method_51448().translate(x, y);
		graphics.method_51448().scale(scale, scale);

		if (centered) {
			page.parent.drawCenteredStringNoShadow(graphics, page.i18n(actualText.getString()), 0, 0, color);
		} else {
			graphics.method_51433(page.fontRenderer, page.i18n(actualText.getString()), 0, 0, color, false);
		}
		graphics.method_51448().popMatrix();
	}

	@Override
	public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
		super.onVariablesAvailable(lookup, registries);
		actualText = lookup.apply(text).as(class_2561.class);
		colorStr = lookup.apply(colorStr);
	}
}
