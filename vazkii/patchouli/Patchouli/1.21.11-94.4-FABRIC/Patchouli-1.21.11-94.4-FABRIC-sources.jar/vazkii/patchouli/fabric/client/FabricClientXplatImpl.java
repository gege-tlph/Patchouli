package vazkii.patchouli.fabric.client;

import org.joml.Matrix3x2f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import vazkii.patchouli.client.multiblock.MultiblockPiPRenderState;
import vazkii.patchouli.common.multiblock.AbstractMultiblock;
import vazkii.patchouli.xplat.IClientXplatAbstractions;

import java.util.function.Function;
import net.minecraft.class_11244;
import net.minecraft.class_11515;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_776;

public class FabricClientXplatImpl implements IClientXplatAbstractions {
	@Override
	public void renderForMultiblock(class_776 blockRenderer, class_2680 state, class_2338 pos, class_1920 multiblock, class_4587 poseStack, Function<class_11515, class_4588> bufferLookup, class_5819 rand) {
		blockRenderer.method_3355(state, pos, multiblock, poseStack, bufferLookup.apply(class_4696.method_23679(state)), false, blockRenderer.method_3349(state).method_68512(rand));
	}

	@Override
	public void submitGuiElement(class_332 graphics, class_11244 renderState) {
		graphics.field_59826.method_70919(renderState);
	}

	@Override
	public void submitMultiblockPiP(class_332 graphics, AbstractMultiblock multiblock, float scale, Vector3f translation, Quaternionf rotation, int x0, int y0, int x1, int y1) {
		graphics.field_59826.method_70922(new MultiblockPiPRenderState(
				multiblock, translation, rotation, x0, y0, x1, y1, scale,
				new Matrix3x2f(graphics.method_51448()), graphics.field_44659.method_70863()
		));
	}
}
