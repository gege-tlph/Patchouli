package vazkii.patchouli.fabric.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.recipe.v1.sync.ClientRecipeSynchronizedEvent;
import net.fabricmc.fabric.api.client.rendering.v1.SpecialGuiElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.class_10443;
import net.minecraft.class_10482;
import net.minecraft.class_3264;
import vazkii.patchouli.client.base.*;
import vazkii.patchouli.client.book.BookContentResourceListenerLoader;
import vazkii.patchouli.client.book.BookReloadHook;
import vazkii.patchouli.client.book.ClientBookRegistry;
import vazkii.patchouli.client.multiblock.MultiblockPiPRenderer;
import vazkii.patchouli.client.handler.BookRightClickHandler;
import vazkii.patchouli.client.handler.MultiblockVisualizationHandler;
import vazkii.patchouli.client.hud.BookOverlayHud;
import vazkii.patchouli.client.hud.MultiblockProgressHud;
import vazkii.patchouli.fabric.network.FabricMessageOpenBookGui;
import vazkii.patchouli.fabric.network.FabricMessageReloadBookContents;
import vazkii.patchouli.network.MessageOpenBookGui;
import vazkii.patchouli.network.MessageReloadBookContents;

public class FabricClientInitializer implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientBookRegistry.INSTANCE.init();
		PersistentData.setup();
		ClientTickEvents.END_CLIENT_TICK.register(ClientTicker::endClientTick);
		HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, BookOverlayHud.ID, BookOverlayHud::render);
		HudElementRegistry.attachElementBefore(VanillaHudElements.BOSS_BAR, MultiblockProgressHud.ID, MultiblockProgressHud::render);
		UseBlockCallback.EVENT.register(BookRightClickHandler::onRightClick);
		UseBlockCallback.EVENT.register(MultiblockVisualizationHandler.INSTANCE::onPlayerInteract);
		ClientTickEvents.END_CLIENT_TICK.register(MultiblockVisualizationHandler.INSTANCE::onClientTick);
		ClientPlayNetworking.registerGlobalReceiver(MessageOpenBookGui.TYPE, FabricMessageOpenBookGui::handle);
		ClientPlayNetworking.registerGlobalReceiver(MessageReloadBookContents.TYPE, FabricMessageReloadBookContents::handle);

		class_10443.field_55336.method_65325(BookModel.Unbaked.ID, BookModel.Unbaked.MAP_CODEC);
		class_10482.field_55408.method_65325(BookCompletionModelProperty.ID, BookCompletionModelProperty.MAP_CODEC);

		ResourceLoader.get(class_3264.field_14188).registerReloader(BookContentResourceListenerLoader.ID, BookContentResourceListenerLoader.INSTANCE);
		ResourceLoader.get(class_3264.field_14188).registerReloader(BookReloadHook.ID, BookReloadHook.INSTANCE);

		ClientRecipeSynchronizedEvent.EVENT.register((minecraft, synchronizedRecipes) -> {
			ClientRecipes.INSTANCE.receivedRecipes(synchronizedRecipes.recipes());
		});
		SpecialGuiElementRegistry.register(ctx -> new MultiblockPiPRenderer(ctx.vertexConsumers(), ctx.client(), ctx.orderedRenderCommandQueue()));
	}
}
