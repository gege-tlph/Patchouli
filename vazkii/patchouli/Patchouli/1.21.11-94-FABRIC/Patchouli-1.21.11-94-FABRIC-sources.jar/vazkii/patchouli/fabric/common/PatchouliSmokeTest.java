package vazkii.patchouli.fabric.common;

import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.class_4516;

public class PatchouliSmokeTest {
	@GameTest()
	public void doesItRun(class_4516 helper) {
		helper.method_36036();
	}
}
