package vazkii.patchouli.fabric.xplat;

import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.recipe.v1.ingredient.DefaultCustomIngredients;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.server.MinecraftServer;
import vazkii.patchouli.api.BookContentsReloadCallback;
import vazkii.patchouli.api.BookDrawScreenCallback;
import vazkii.patchouli.fabric.client.rei.ReiCompat;
import vazkii.patchouli.fabric.network.FabricMessageOpenBookGui;
import vazkii.patchouli.fabric.network.FabricMessageReloadBookContents;
import vazkii.patchouli.xplat.IXplatAbstractions;
import vazkii.patchouli.xplat.XplatModContainer;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class FabricXplatImpl implements IXplatAbstractions {
	@Override
	public void fireDrawBookScreen(class_2960 book, class_437 gui, int mouseX, int mouseY, float partialTicks, class_332 graphics) {
		BookDrawScreenCallback.EVENT.invoker().trigger(book, gui, mouseX, mouseY, partialTicks, graphics);
	}

	@Override
	public void fireBookReload(class_2960 book) {
		BookContentsReloadCallback.EVENT.invoker().trigger(book);
	}

	@Override
	public void sendReloadContentsMessage(MinecraftServer server) {
		FabricMessageReloadBookContents.sendToAll(server);
	}

	@Override
	public void sendOpenBookGui(class_3222 player, class_2960 book, @Nullable class_2960 entry, int page) {
		FabricMessageOpenBookGui.send(player, book, entry, page);
	}

	@Override
	public Collection<XplatModContainer> getAllMods() {
		List<XplatModContainer> ret = new ArrayList<>();
		for (var mod : FabricLoader.getInstance().getAllMods()) {
			ret.add(new FabricXplatModContainer(mod));
		}
		return ret;
	}

	@Override
	public XplatModContainer getModContainer(String modId) {
		return new FabricXplatModContainer(FabricLoader.getInstance().getModContainer(modId).get());
	}

	@Override
	public boolean isModLoaded(String modId) {
		return FabricLoader.getInstance().isModLoaded(modId);
	}

	@Override
	public boolean isDevEnvironment() {
		return FabricLoader.getInstance().isDevelopmentEnvironment();
	}

	@Override
	public boolean isPhysicalClient() {
		return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
	}

	@Override
	public boolean handleRecipeKeybind(int keyCode, int scanCode, @Nullable class_1799 stack) {
		if (stack == null || stack.method_7960()) {
			return false;
		}
		if (FabricLoader.getInstance().isModLoaded("roughlyenoughitems")) {
			return ReiCompat.handleRecipeKeybind(keyCode, scanCode, stack);
		}
		return false;
	}

	@Override
	public class_1856 createComponentIngredient(class_1799 itemStack) {
		return DefaultCustomIngredients.components(itemStack);
	}

	@Override
	public class_1856 createCompoundIngredient(class_1856[] ingredients) {
		return DefaultCustomIngredients.any(ingredients);
	}
}
