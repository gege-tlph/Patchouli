package vazkii.patchouli.api.stub;

import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import vazkii.patchouli.api.IStateMatcher;
import vazkii.patchouli.api.TriPredicate;

public final class StubMatcher implements IStateMatcher {

	public static final StubMatcher INSTANCE = new StubMatcher();

	private final class_2680 state = class_2246.field_10124.method_9564();

	private StubMatcher() {}

	@Override
	public class_2680 getDisplayedState(long ticks) {
		return state;
	}

	@Override
	public TriPredicate<class_1922, class_2338, class_2680> getStatePredicate() {
		return (w, p, s) -> false;
	}

}
