package vazkii.patchouli.common.item;

import vazkii.patchouli.api.PatchouliAPI;

import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_9331;

public class PatchouliDataComponents {

	public static final class_2960 COMPONENT_ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "book");
	public static final class_9331<class_2960> BOOK = class_9331.<class_2960>method_57873()
			.method_57881(class_2960.field_25139)
			.method_57882(class_2960.field_48267)
			.method_57880();

	public static void submitDataComponentRegistrations(BiConsumer<class_2960, class_9331<?>> consumer) {
		consumer.accept(COMPONENT_ID, BOOK);
	}
}
