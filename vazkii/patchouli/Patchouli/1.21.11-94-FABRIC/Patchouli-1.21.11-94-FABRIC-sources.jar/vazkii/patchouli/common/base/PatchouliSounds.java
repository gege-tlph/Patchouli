package vazkii.patchouli.common.base;

import vazkii.patchouli.api.PatchouliAPI;

import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class PatchouliSounds {

	public static final class_5321<class_3414> BOOK_OPEN = class_5321.method_29179(class_7924.field_41225, class_2960.method_60655(PatchouliAPI.MOD_ID, "book_open"));
	public static final class_5321<class_3414> BOOK_FLIP = class_5321.method_29179(class_7924.field_41225, class_2960.method_60655(PatchouliAPI.MOD_ID, "book_flip"));

	public static void submitRegistrations(BiConsumer<class_2960, class_3414> e) {
		e.accept(BOOK_OPEN.method_29177(), class_3414.method_47908(BOOK_OPEN.method_29177()));
		e.accept(BOOK_FLIP.method_29177(), class_3414.method_47908(BOOK_FLIP.method_29177()));
	}

	public static class_3414 getSound(class_2960 key, class_5321<class_3414> fallback) {
		return class_7923.field_41172.method_17966(key).orElseGet(() -> class_7923.field_41172.method_29107(fallback));
	}

}
