package vazkii.patchouli.common.base;

import com.google.common.base.Preconditions;
import org.apache.commons.io.IOUtils;

import vazkii.patchouli.api.*;
import vazkii.patchouli.api.PatchouliAPI.IPatchouliAPI;
import vazkii.patchouli.client.book.BookContents;
import vazkii.patchouli.client.book.ClientBookRegistry;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.template.BookTemplate;
import vazkii.patchouli.client.book.text.BookTextParser;
import vazkii.patchouli.client.handler.MultiblockVisualizationHandler;
import vazkii.patchouli.common.advancement.BookOpenTrigger;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.book.BookRegistry;
import vazkii.patchouli.common.item.ItemModBook;
import vazkii.patchouli.common.multiblock.DenseMultiblock;
import vazkii.patchouli.common.multiblock.MultiblockRegistry;
import vazkii.patchouli.common.multiblock.SparseMultiblock;
import vazkii.patchouli.common.multiblock.StateMatcher;
import vazkii.patchouli.xplat.IXplatAbstractions;

import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_437;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public class PatchouliAPIImpl implements IPatchouliAPI {

	private static void assertPhysicalClient() {
		Preconditions.checkState(
				IXplatAbstractions.INSTANCE.isPhysicalClient(),
				"Not on the physical client"
		);
	}

	@Override
	public boolean isStub() {
		return false;
	}

	@NotNull
	@Override
	public PatchouliConfigAccess getConfig() {
		return PatchouliConfig.get();
	}

	@Override
	public void setConfigFlag(String flag, boolean value) {
		PatchouliConfig.setFlag(flag, value);
	}

	@Override
	public boolean getConfigFlag(String flag) {
		return PatchouliConfig.getConfigFlag(flag);
	}

	@Override
	public void openBookGUI(class_3222 player, class_2960 book) {
		BookOpenTrigger.INSTANCE.trigger(player, book);
		IXplatAbstractions.INSTANCE.sendOpenBookGui(player, book, null, 0);
	}

	@Override
	public void openBookEntry(class_3222 player, class_2960 book, class_2960 entry, int page) {
		BookOpenTrigger.INSTANCE.trigger(player, book, entry, page);
		IXplatAbstractions.INSTANCE.sendOpenBookGui(player, book, entry, page);
	}

	@Override
	public void openBookGUI(class_2960 book) {
		assertPhysicalClient();
		ClientBookRegistry.INSTANCE.displayBookGui(book, null, 0);
	}

	@Override
	public void openBookEntry(class_2960 book, class_2960 entry, int page) {
		assertPhysicalClient();
		ClientBookRegistry.INSTANCE.displayBookGui(book, entry, page);
	}

	@Override
	public class_2960 getOpenBookGui() {
		assertPhysicalClient();
		class_437 gui = class_310.method_1551().field_1755;
		if (gui instanceof GuiBook) {
			return ((GuiBook) gui).book.id;
		}
		return null;
	}

	@NotNull
	@Override
	public class_2561 getSubtitle(@NotNull class_2960 bookId) {
		Book book = BookRegistry.INSTANCE.books.get(bookId);
		if (book == null) {
			throw new IllegalArgumentException("Book not found: " + bookId);
		}
		return book.getSubtitle();
	}

	@Override
	public void registerCommand(String name, Function<IStyleStack, String> command) {
		assertPhysicalClient();
		BookTextParser.register(command::apply, name);
	}

	@Override
	public void registerFunction(String name, BiFunction<String, IStyleStack, String> function) {
		assertPhysicalClient();
		BookTextParser.register(function::apply, name);
	}

	@Override
	public class_1799 getBookStack(class_2960 book) {
		return ItemModBook.forBook(book);
	}

	@Override
	public void registerTemplateAsBuiltin(class_2960 res, Supplier<InputStream> streamProvider) {
		assertPhysicalClient();
		InputStream testStream = streamProvider.get();
		if (testStream == null) {
			throw new NullPointerException("Stream provider can't return a null stream");
		}
		IOUtils.closeQuietly(testStream);

		Supplier<BookTemplate> prev = BookContents.addonTemplates.put(res, () -> {
			InputStream stream = streamProvider.get();
			InputStreamReader reader = new InputStreamReader(stream);
			return ClientBookRegistry.INSTANCE.gson.fromJson(reader, BookTemplate.class);
		});

		if (prev != null) {
			throw new IllegalArgumentException("Template " + res + " is already registered");
		}
	}

	@Override
	public IMultiblock getMultiblock(class_2960 res) {
		return MultiblockRegistry.MULTIBLOCKS.get(res);
	}

	@Override
	public IMultiblock registerMultiblock(class_2960 res, IMultiblock mb) {
		return MultiblockRegistry.registerMultiblock(res, mb);
	}

	@Override
	public IMultiblock getCurrentMultiblock() {
		assertPhysicalClient();
		return MultiblockVisualizationHandler.INSTANCE.hasMultiblock() ? MultiblockVisualizationHandler.INSTANCE.getMultiblock() : null;
	}

	@Override
	public void showMultiblock(@NotNull IMultiblock multiblock, @NotNull class_2561 displayName, @NotNull class_2338 center, @NotNull class_2470 rotation) {
		assertPhysicalClient();
		MultiblockVisualizationHandler.INSTANCE.setMultiblock(multiblock, displayName, null, false);
		MultiblockVisualizationHandler.INSTANCE.anchorTo(center, rotation);
	}

	@Override
	public void clearMultiblock() {
		assertPhysicalClient();
		MultiblockVisualizationHandler.INSTANCE.setMultiblock(null, null, null, false);
	}

	@Override
	public IMultiblock makeMultiblock(String[][] pattern, Object... targets) {
		return new DenseMultiblock(pattern, targets);
	}

	@Override
	public IMultiblock makeSparseMultiblock(Map<class_2338, IStateMatcher> positions) {
		return new SparseMultiblock(positions);
	}

	@Override
	public IStateMatcher predicateMatcher(class_2680 display, Predicate<class_2680> predicate) {
		return StateMatcher.fromPredicate(display, predicate);
	}

	@Override
	public IStateMatcher predicateMatcher(class_2248 display, Predicate<class_2680> predicate) {
		return StateMatcher.fromPredicate(display, predicate);
	}

	@Override
	public IStateMatcher stateMatcher(class_2680 state) {
		return StateMatcher.fromState(state);
	}

	@Override
	public IStateMatcher propertyMatcher(class_2680 state, class_2769<?>... properties) {
		return StateMatcher.fromStateWithFilter(state, Arrays.asList(properties)::contains);
	}

	@Override
	public IStateMatcher looseBlockMatcher(class_2248 block) {
		return StateMatcher.fromBlockLoose(block);
	}

	@Override
	public IStateMatcher strictBlockMatcher(class_2248 block) {
		return StateMatcher.fromBlockStrict(block);
	}

	@Override
	public IStateMatcher displayOnlyMatcher(class_2680 state) {
		return StateMatcher.displayOnly(state);
	}

	@Override
	public IStateMatcher displayOnlyMatcher(class_2248 block) {
		return StateMatcher.displayOnly(block);
	}

	@NotNull
	@Override
	public IStateMatcher tagMatcher(@NotNull class_6862<class_2248> tag) {
		/* TODO deduplicate with StringStateMatcher's version. This one is okay with
		* tags that don't exist but that one validates that the tag exists.
		*/
		return new IStateMatcher() {
			@NotNull
			@Override
			public class_2680 getDisplayedState(long ticks) {
				return class_7923.field_41175.method_46733(tag).map(n -> {
					int idx = (int) ((ticks / 20) % n.method_40247());
					return n.method_40240(idx).comp_349().method_9564();
				}).orElse(class_2246.field_9987.method_9564());
			}

			@NotNull
			@Override
			public TriPredicate<class_1922, class_2338, class_2680> getStatePredicate() {
				return (w, p, s) -> s.method_26164(tag);
			}
		};
	}

	@Override
	public IStateMatcher airMatcher() {
		return StateMatcher.AIR;
	}

	@Override
	public IStateMatcher anyMatcher() {
		return StateMatcher.ANY;
	}

}
