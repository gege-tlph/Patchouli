package vazkii.patchouli.common.item;

import vazkii.patchouli.api.PatchouliAPI;

import java.util.function.BiConsumer;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class PatchouliItems {

	public static final class_2960 BOOK_ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "guide_book");
	public static final class_1792 BOOK = new ItemModBook(new class_1792.class_1793().method_7889(1).method_63686(class_5321.method_29179(class_7924.field_41197, BOOK_ID)));

	public static void submitItemRegistrations(BiConsumer<class_2960, class_1792> consumer) {
		consumer.accept(BOOK_ID, BOOK);
	}
}
