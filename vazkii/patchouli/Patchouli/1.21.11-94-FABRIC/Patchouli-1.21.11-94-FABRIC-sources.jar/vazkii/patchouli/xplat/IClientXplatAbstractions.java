package vazkii.patchouli.xplat;

import org.joml.Quaternionf;
import org.joml.Vector3f;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.multiblock.AbstractMultiblock;

import java.util.ServiceLoader;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_11244;
import net.minecraft.class_11515;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;

public interface IClientXplatAbstractions {
	IClientXplatAbstractions INSTANCE = find();

	private static IClientXplatAbstractions find() {
		var providers = ServiceLoader.load(IClientXplatAbstractions.class, IClientXplatAbstractions.class.getClassLoader()).stream().toList();
		if (providers.size() != 1) {
			var names = providers.stream().map(p -> p.type().getName()).collect(Collectors.joining(",", "[", "]"));
			throw new IllegalStateException("There should be exactly one IClientXplatAbstractions implementation on the classpath. Found: " + names);
		} else {
			var provider = providers.getFirst();
			PatchouliAPI.LOGGER.debug("Instantiating client xplat impl: {}", provider.type().getName());
			return provider.get();
		}
	}

	// NB: Fluids handled at callsite in platform-independent manner
	void renderForMultiblock(class_776 blockRenderer, class_2680 state, class_2338 pos, class_1920 multiblock, class_4587 poseStack, Function<class_11515, class_4588> bufferLookup, class_5819 rand);

	void submitGuiElement(class_332 graphics, class_11244 renderState);
	
	void submitMultiblockPiP(class_332 graphics, AbstractMultiblock multiblock, float scale, Vector3f translation, Quaternionf rotation, int x0, int y0, int x1, int y1);
}
