package vazkii.patchouli.client.hud;

import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.handler.MultiblockVisualizationHandler;

import java.awt.*;
import net.minecraft.class_1074;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9779;

public final class MultiblockProgressHud {
	public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "multiblock_progress");

	private MultiblockProgressHud() {}

	public static void render(class_332 graphics, class_9779 deltaTracker) {
		MultiblockVisualizationHandler handler = MultiblockVisualizationHandler.INSTANCE;
		if (!handler.hasMultiblock()) {
			return;
		}

		int waitTime = 40;
		int fadeOutSpeed = 4;
		int fullAnimTime = waitTime + 10;
		float animTime = handler.getTimeComplete() + (handler.getTimeComplete() == 0 ? 0 : deltaTracker.method_60637(false));

		if (animTime > fullAnimTime) {
			handler.setHasMultiblock(false);
			return;
		}

		graphics.method_51448().pushMatrix();
		graphics.method_51448().translate(0, -Math.max(0, animTime - waitTime) * fadeOutSpeed);

		class_310 mc = class_310.method_1551();
		int x = mc.method_22683().method_4486() / 2;
		int y = 12;

		graphics.method_27534(mc.field_1772, handler.name(), x, y, 0xFFFFFF);

		int width = 180;
		int height = 9;
		int left = x - width / 2;
		int top = y + 10;

		if (handler.getTimeComplete() > 0) {
			graphics.method_51448().pushMatrix();
			graphics.method_51448().translate(0, Math.min(height + 5, animTime));
			graphics.method_27534(mc.field_1772, class_2561.method_43471("patchouli.gui.lexicon.structure_complete"), x, top + height - 10, 0x00FF00);
			graphics.method_51448().popMatrix();
		}

		graphics.method_25294(left - 1, top - 1, left + width + 1, top + height + 1, 0xFF000000);
		graphics.method_25296(left, top, left + width, top + height, 0xFF666666, 0xFF555555);

		float fract = handler.getProgress();
		int progressWidth = (int) ((float) width * fract);
		int color = class_3532.method_15369(fract / 3.0F, 1.0F, 1.0F) | 0xFF000000;
		int color2 = new Color(color).darker().getRGB();
		graphics.method_25296(left, top, left + progressWidth, top + height, color, color2);

		if (!handler.isAnchored()) {
			graphics.method_27534(mc.field_1772, class_2561.method_43471("patchouli.gui.lexicon.not_anchored"), x, top + height + 8, 0xFFFFFF);
		} else {
			class_2680 lookingState = handler.getLookingState();
			if (lookingState != null) {
				// try-catch around here because the state isn't necessarily present in the world in this instance,
				// which isn't really expected behavior for getPickBlock
				try {
					class_1799 stack = lookingState.method_65171(mc.field_1687, handler.getLookingPos(), false);

					if (!stack.method_7960()) {
						graphics.method_51439(mc.field_1772, stack.method_7964(), left + 20, top + height + 8, 0xFFFFFF, true);
						graphics.method_51427(stack, left, top + height + 2);
					}
				} catch (Exception ignored) {}
			}

			if (handler.getTimeComplete() == 0) {
				color = 0xFFFFFF;
				int posx = left + width;
				int posy = top + height + 2;
				int mult = 1;
				String progress = handler.getProgressString();

				if (handler.isComplete()) {
					progress = class_1074.method_4662("patchouli.gui.lexicon.needs_air");
					color = 0xDA4E3F;
					mult *= 2;
					posx -= width / 2;
					posy += 2;
				}

				graphics.method_51433(mc.field_1772, progress, posx - mc.field_1772.method_1727(progress) / mult, posy, color, false);
			}
		}

		graphics.method_51448().popMatrix();
	}
}
