package vazkii.patchouli.client.book.page;

import net.minecraft.class_10314;
import net.minecraft.class_10352;
import net.minecraft.class_10799;
import net.minecraft.class_332;
import net.minecraft.class_3956;
import net.minecraft.class_8059;
import net.minecraft.world.item.crafting.*;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.page.abstr.PageDoubleRecipeRegistry;

public class PageSmithing extends PageDoubleRecipeRegistry<class_8059, class_10314> {

	public PageSmithing() {
		super(class_3956.field_25388, class_10314.class);
	}

	@Override
	protected void drawRecipe(class_332 graphics, class_10314 recipe, class_10352 context, int recipeX, int recipeY, int mouseX, int mouseY, boolean second) {
		graphics.method_25290(class_10799.field_56883, book.craftingTexture, recipeX, recipeY, 11, 135, 96, 43, 128, 256);
		parent.drawCenteredStringNoShadow(graphics, getTitle(second).method_30937(), GuiBook.PAGE_WIDTH / 2, recipeY - 10, book.headerColor);
		parent.renderItemStack(graphics, recipeX + 4, recipeY + 4, mouseX, mouseY, recipe.comp_3303().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 4, recipeY + 23, mouseX, mouseY, recipe.comp_3304().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 40, recipeY + 4, mouseX, mouseY, recipe.comp_3302().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 40, recipeY + 20, mouseX, mouseY, recipe.comp_3259().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 76, recipeY + 13, mouseX, mouseY, recipe.comp_3258().method_64742(context));
	}

	@Override
	protected int getRecipeHeight() {
		return 60;
	}
}
