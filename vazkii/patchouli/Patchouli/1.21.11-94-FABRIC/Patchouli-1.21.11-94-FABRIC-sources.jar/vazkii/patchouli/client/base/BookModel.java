package vazkii.patchouli.client.base;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10430;
import net.minecraft.class_10439;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_811;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.item.ItemModBook;

import org.jetbrains.annotations.Nullable;

public class BookModel implements class_10439 {
	private final class_10439 base;

	public BookModel(class_10439 base) {
		this.base = base;
	}

	@Override
	public void method_65584(class_10444 renderState, class_1799 stack, class_10442 itemModelResolver, class_811 displayContext, @Nullable class_638 level, @Nullable class_11566 owner, int seed) {
		renderState.method_70946(this);
		Book book = ItemModBook.getBook(stack);
		class_10439 model;
		if (book == null) {
			model = base;
		} else {
			model = class_310.method_1551().method_1554().method_65746(book.model);
		}
		model.method_65584(renderState, stack, itemModelResolver, displayContext, level, owner, seed);
	}

	public record Unbaked(class_10430.class_10431 base) implements class_10439.class_10441 {
		public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "book");
		public static final MapCodec<Unbaked> MAP_CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
				class_10430.class_10431.field_55324.forGetter(Unbaked::base)
		).apply(inst, Unbaked::new));

		@Override
		public MapCodec<? extends class_10439.class_10441> method_65585() {
			return MAP_CODEC;
		}

		@Override
		public class_10439 method_65587(class_10440 context) {
			return new BookModel(base().method_65587(context));
		}

		@Override
		public void method_62326(class_10103 resolver) {
			base().method_62326(resolver);
		}
	}
}
