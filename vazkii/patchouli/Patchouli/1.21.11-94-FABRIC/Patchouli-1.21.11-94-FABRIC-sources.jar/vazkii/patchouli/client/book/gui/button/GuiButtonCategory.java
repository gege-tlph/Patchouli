package vazkii.patchouli.client.book.gui.button;

import net.minecraft.class_1144;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_9848;
import org.jspecify.annotations.Nullable;

import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.book.BookCategory;
import vazkii.patchouli.client.book.BookIcon;
import vazkii.patchouli.client.book.gui.GuiBook;

public class GuiButtonCategory extends class_4185 {

	private static final int ANIM_TIME = 5;

	private final GuiBook parent;
	private @Nullable BookCategory category;
	private final BookIcon icon;
	private final class_2561 name;
	private final int u, v;
	private float timeHovered;

	public GuiButtonCategory(GuiBook parent, int x, int y, BookCategory category, class_4185.class_4241 onPress) {
		this(parent, x, y, category.getIcon(), category.getName(), onPress);
		this.category = category;
	}

	public GuiButtonCategory(GuiBook parent, int x, int y, BookIcon icon, class_2561 name, class_4185.class_4241 onPress) {
		super(parent.bookLeft + x, parent.bookTop + y, 20, 20, name, onPress, field_40754);
		this.parent = parent;
		this.u = x;
		this.v = y;
		this.icon = icon;
		this.name = name;
	}

	@Override
	protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (field_22763) {
			if (method_25367()) {
				timeHovered = Math.min(ANIM_TIME, timeHovered + ClientTicker.delta);
			} else {
				timeHovered = Math.max(0, timeHovered - ClientTicker.delta);
			}

			float time = Math.max(0, Math.min(ANIM_TIME, timeHovered + (method_25367() ? partialTicks : -partialTicks)));
			float transparency = 0.5F - (time / ANIM_TIME) * 0.5F;
			boolean locked = category != null && category.isLocked();

			graphics.method_51448().pushMatrix();
			graphics.method_51448().translate(method_46426(), method_46427());
			if (locked) {
				GuiBook.drawLock(graphics, parent.book, 2, 2, class_9848.method_71346(0.7F, 0xffffff));
			} else {
				icon.render(graphics, 2, 2);
			}

			graphics.method_51448().pushMatrix();
			GuiBook.drawFromTexture(graphics, parent.book, 0, 0, u, v, field_22758, field_22759, class_9848.method_71346(transparency, 0xffffff));

			if (category != null && !category.isLocked()) {
				GuiBook.drawMarking(graphics, parent.book, 0, 0, 0, category.getReadState());
			}
			graphics.method_51448().popMatrix();
			graphics.method_51448().popMatrix();

			if (method_25367()) {
				parent.setTooltip(locked
						? class_2561.method_43471("patchouli.gui.lexicon.locked").method_27692(class_124.field_1080)
						: name);
			}
		}
	}

	@Override
	public void method_25354(class_1144 soundHandlerIn) {
		if (category != null && !category.isLocked()) {
			GuiBook.playBookFlipSound(parent.book);
		}
	}

	public @Nullable BookCategory getCategory() {
		return category;
	}

}
