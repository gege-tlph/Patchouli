package vazkii.patchouli.client.base;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_1800;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.item.ItemModBook;
import vazkii.patchouli.common.item.PatchouliItems;

import org.jetbrains.annotations.Nullable;

public class BookCompletionModelProperty implements class_1800 {
	public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "completion");
	public static final MapCodec<BookCompletionModelProperty> MAP_CODEC = MapCodec.unit(new BookCompletionModelProperty());

	@Override
	public float method_65644(class_1799 stack, @Nullable class_638 level, @Nullable class_11566 owner, int seed) {
		return stack.method_31574(PatchouliItems.BOOK) ? ItemModBook.getCompletion(stack) : 0;
	}

	@Override
	public MapCodec<? extends class_1800> method_65643() {
		return MAP_CODEC;
	}
}
