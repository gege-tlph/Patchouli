package vazkii.patchouli.client.book;

import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/**
 * Since {@link net.minecraft.class_775} doesn't use the pose stack at all, we need to
 * both (1) un-transform the positions by {@code pos}, and also re-transform them using the {@link class_4587}.
 */
public record LiquidBlockVertexConsumer(class_4588 prior, class_4587 pose, class_2338 pos) implements class_4588 {

	@Override
	public class_4588 method_22912(float x, float y, float z) {
		final float dx = pos.method_10263() & 15;
		final float dy = pos.method_10264() & 15;
		final float dz = pos.method_10260() & 15;
		return prior.method_22918(pose.method_23760().method_23761(), x - dx, y - dy, z - dz);
	}

	@Override
	public class_4588 method_1336(int r, int g, int b, int a) {
		return prior.method_1336(r, g, b, a);
	}

	@Override
	public class_4588 method_39415(int i) {
		return prior.method_39415(i);
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		return prior.method_22913(u, v);
	}

	@Override
	public class_4588 method_60796(int u, int v) {
		return prior.method_60796(u, v);
	}

	@Override
	public class_4588 method_22922(int uv) {
		return prior.method_60796(uv & 65535, uv >> 16 & 65535);
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		return prior.method_22921(u, v);
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		return prior.method_60831(pose.method_23760(), x, y, z);
	}

	@Override
	public class_4588 method_75298(float v) {
		return prior.method_75298(v);
	}

}
