package vazkii.patchouli.client.handler;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.util.ItemStackUtil;

import org.jetbrains.annotations.Nullable;

public class BookRightClickHandler {
	public static class_1269 onRightClick(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
		class_1799 bookStack = player.method_6047();

		if (world.method_8608() && player.method_5715()) {
			Book book = ItemStackUtil.getBookFromStack(bookStack);

			if (book != null) {
				Pair<BookEntry, Integer> hover = getHoveredEntry(book);
				if (hover != null) {
					int page = hover.getSecond() * 2;
					book.getContents().setTopEntry(hover.getFirst().getId(), page);
				}
			}
		}
		return class_1269.field_5811;
	}

	@Nullable
	public static Pair<BookEntry, Integer> getHoveredEntry(Book book) {
		class_310 mc = class_310.method_1551();
		class_239 res = mc.field_1765;
		if (mc.field_1687 != null && res instanceof class_3965 hit) {
			class_2338 pos = hit.method_17777();
			class_2680 state = mc.field_1687.method_8320(pos);
			class_1799 picked = state.method_65171(mc.field_1687, pos, false);

			if (!picked.method_7960()) {
				return book.getContents().getEntryForStack(picked);
			}
		}

		return null;
	}
}
