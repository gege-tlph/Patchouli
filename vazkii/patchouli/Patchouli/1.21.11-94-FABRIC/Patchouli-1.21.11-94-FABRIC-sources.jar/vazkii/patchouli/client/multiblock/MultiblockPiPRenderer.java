package vazkii.patchouli.client.multiblock;

import vazkii.patchouli.client.book.LiquidBlockVertexConsumer;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.common.multiblock.AbstractMultiblock;
import vazkii.patchouli.xplat.IClientXplatAbstractions;

import java.util.function.Function;
import net.minecraft.class_11239;
import net.minecraft.class_11515;
import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_4076;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4696;
import net.minecraft.class_4722;
import net.minecraft.class_5819;
import net.minecraft.class_750;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_824;
import net.minecraft.class_8251;
import net.minecraft.class_827;
import net.minecraft.class_853;
import net.minecraft.class_9810;

public class MultiblockPiPRenderer extends class_11239<MultiblockPiPRenderState> {
	private static final class_5819 RAND = class_5819.method_43053();
	private final class_310 mc;
	private final class_11659 submitNodeCollector;
	private final class_824 blockEntityRenderer;
	private final class_776 blockRenderer;

	public MultiblockPiPRenderer(class_4597.class_4598 bufferSource, class_310 mc, class_11659 submitNodeCollector) {
		super(bufferSource);
		this.mc = mc;
		this.submitNodeCollector = submitNodeCollector;
		this.blockEntityRenderer = mc.method_31975();
		this.blockRenderer = mc.method_1541();
	}

	@Override
	public Class<MultiblockPiPRenderState> method_70903() {
		return MultiblockPiPRenderState.class;
	}

	/**
	 * @implNote Adapted from {@link class_9810#method_60904(class_4076, class_853, class_8251, class_750)}
	 */
	@Override
	protected void renderToTexture(MultiblockPiPRenderState renderState, class_4587 poseStack) {
		AbstractMultiblock multiblock = renderState.multiblock();
		multiblock.setWorld(mc.field_1687);
		class_238 bounds = multiblock.getBounds();
		double sizeX = bounds.method_17939();
		double sizeY = bounds.method_17940();
		double sizeZ = bounds.method_17941();
		double maxX = 90;
		double maxY = 90;
		double diag = Math.sqrt(sizeX * sizeX + sizeZ * sizeZ);
		double scaleX = maxX / diag;
		double scaleY = maxY / sizeY;
		float scale = (float) -Math.min(scaleX, scaleY);

		int xPos = GuiBook.PAGE_WIDTH / 2;
		int yPos = 60;
		poseStack.method_22903();
		poseStack.method_46416(xPos, yPos, 0);
		poseStack.method_22905(scale, scale, scale);
		poseStack.method_46416(-(float) sizeX / 2, -(float) sizeY / 2, 0);

		poseStack.method_22907(class_7833.field_40714.rotationDegrees(-30F));

		float offX = (float) -sizeX / 2;
		float offZ = (float) -sizeZ / 2 + 1;

		poseStack.method_46416(-offX, 0, -offZ);
		poseStack.method_22907(renderState.rotation());
		poseStack.method_46416(offX, 0, offZ);

		Function<class_11515, class_4588> bufferLookup = layer -> field_59933.method_73477(layer != class_11515.field_60926 ? class_4722.method_24074() : class_4722.method_76545());
		class_12075 cameraRenderState = new class_12075();

		for (class_2338 pos : class_2338.method_62671(bounds)) {
			class_2680 blockstate = multiblock.method_8320(pos);

			if (blockstate.method_31709()) {
				class_2586 blockentity = multiblock.method_8321(pos);
				if (blockentity != null) {
					this.handleBlockEntity(blockentity, poseStack, cameraRenderState);
				}
			}

			class_3610 fluidstate = blockstate.method_26227();
			if (!fluidstate.method_15769()) {
				class_11515 layer = class_4696.method_23680(fluidstate);
				blockRenderer.method_3352(pos, multiblock, new LiquidBlockVertexConsumer(bufferLookup.apply(layer), poseStack, pos), blockstate, fluidstate);
			}

			if (blockstate.method_26217() == class_2464.field_11458) {
				RAND.method_43052(blockstate.method_26190(pos));
				IClientXplatAbstractions.INSTANCE.renderForMultiblock(blockRenderer, blockstate, pos, multiblock, poseStack, bufferLookup, RAND);
			}
		}

		poseStack.method_22909();
	}

	private <E extends class_2586, S extends class_11954> void handleBlockEntity(E blockEntity, class_4587 poseStack, class_12075 cameraRenderState) {
		class_827<E, S> renderer = blockEntityRenderer.method_3550(blockEntity);
		if (renderer == null) {
			return;
		}
		S renderState = renderer.method_74335();
		renderer.method_74331(blockEntity, renderState, 0, cameraRenderState.field_63078, null);
		renderer.method_3569(renderState, poseStack, submitNodeCollector, cameraRenderState);
	}

	@Override
	protected String method_70906() {
		return "patchouli_multiblock";
	}
}
