package vazkii.patchouli.client.book;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4013;
import vazkii.patchouli.api.PatchouliAPI;

public final class BookReloadHook implements class_4013 {
	public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "reload_hook");
	public static final class_4013 INSTANCE = new BookReloadHook();

	@Override
	public void method_14491(class_3300 manager) {
		if (class_310.method_1551().field_1687 != null) {
			PatchouliAPI.LOGGER.info("Reloading resource pack-based books");
			ClientBookRegistry.INSTANCE.reload();
		} else {
			PatchouliAPI.LOGGER.debug("Not reloading resource pack-based books as client world is missing");
		}
	}
}
