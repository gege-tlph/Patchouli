package vazkii.patchouli.client.book.page.abstr;

import net.minecraft.class_10295;
import net.minecraft.class_10302;
import net.minecraft.class_10352;
import net.minecraft.class_10799;
import net.minecraft.class_1860;
import net.minecraft.class_332;
import net.minecraft.class_3956;
import vazkii.patchouli.client.book.gui.GuiBook;

public abstract class PageSimpleProcessingRecipe<T extends class_1860<?>, D extends class_10295> extends PageDoubleRecipeRegistry<T, D> {
	public PageSimpleProcessingRecipe(class_3956<T> recipeType, Class<D> displayClass) {
		super(recipeType, displayClass);
	}

	@Override
	protected void drawRecipe(class_332 graphics, D recipe, class_10352 context, int recipeX, int recipeY, int mouseX, int mouseY, boolean second) {
		graphics.method_25291(class_10799.field_56883, book.craftingTexture, recipeX, recipeY, 11, 71, 96, 24, 128, 256, 0xffffffff);
		parent.drawCenteredStringNoShadow(graphics, getTitle(second).method_30937(), GuiBook.PAGE_WIDTH / 2, recipeY - 10, book.headerColor);
		parent.renderItemStack(graphics, recipeX + 4, recipeY + 4, mouseX, mouseY, getIngredient(recipe).method_64742(context));
		parent.renderItemStack(graphics, recipeX + 40, recipeY + 4, mouseX, mouseY, recipe.comp_3259().method_64742(context));
		parent.renderItemStack(graphics, recipeX + 76, recipeY + 4, mouseX, mouseY, recipe.comp_3258().method_64742(context));
	}

	@Override
	protected int getRecipeHeight() {
		return 45;
	}

	protected abstract class_10302 getIngredient(D display);
}
