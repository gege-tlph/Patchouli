package vazkii.patchouli.client.multiblock;

import net.minecraft.class_11256;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import vazkii.patchouli.common.multiblock.AbstractMultiblock;

public record MultiblockPiPRenderState(
		AbstractMultiblock multiblock,
		Vector3f translation,
		Quaternionf rotation,
		int x0,
		int y0,
		int x1,
		int y1,
		float scale,
		Matrix3x2f pose,
		@Nullable class_8030 scissorArea,
		@Nullable class_8030 bounds
) implements class_11256 {
	public MultiblockPiPRenderState(
			AbstractMultiblock multiblock,
			Vector3f translation,
			Quaternionf rotation,
			int x0,
			int y0,
			int x1,
			int y1,
			float scale,
			Matrix3x2f pose,
			@Nullable class_8030 scissorArea
	) {
		this(
			multiblock,
			translation,
			rotation,
			x0,
			y0,
			x1,
			y1,
			scale,
			pose,
			scissorArea,
			class_11256.method_71535(x0, y0, x1, y1, scissorArea)
		);
	}
}
