package vazkii.patchouli.client.handler;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.datafixers.util.Pair;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.ClientBookRegistry;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.common.base.PatchouliConfig;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.util.ItemStackUtil;
import vazkii.patchouli.xplat.IClientXplatAbstractions;

import org.jetbrains.annotations.Nullable;

public class TooltipHandler {
	private static float lexiconLookupTime = 0;

	public static void onTooltip(class_332 graphics, class_1799 stack, int mouseX, int mouseY) {
		class_310 mc = class_310.method_1551();
		int tooltipX = mouseX;
		int tooltipY = mouseY - 4;

		if (mc.field_1724 != null && !(mc.field_1755 instanceof GuiBook)) {
			int lexSlot = -1;
			class_1799 lexiconStack = class_1799.field_8037;
			Pair<BookEntry, Integer> lexiconEntry = null;

			for (int i = 0; i < class_1661.method_7368(); i++) {
				class_1799 stackAt = mc.field_1724.method_31548().method_5438(i);
				if (!stackAt.method_7960()) {
					Book book = ItemStackUtil.getBookFromStack(stackAt);
					if (book != null) {
						Pair<BookEntry, Integer> entry = book.getContents().getEntryForStack(stack);

						if (entry != null && !entry.getFirst().isLocked()) {
							lexiconStack = stackAt;
							lexSlot = i;
							lexiconEntry = entry;
							break;
						}
					}
				}
			}

			if (lexSlot > -1) {
				int x = tooltipX - 34;

				graphics.method_25294(x - 4, tooltipY - 4, x + 20, tooltipY + 26, 0x44000000);
				graphics.method_25294(x - 6, tooltipY - 6, x + 22, tooltipY + 28, 0x44000000);

				if (PatchouliConfig.get().useShiftForQuickLookup() ? mc.method_74187() : mc.method_74188()) {
					lexiconLookupTime += ClientTicker.delta;

					int cx = x + 8;
					int cy = tooltipY + 8;
					float r = 12;
					float requiredTime = PatchouliConfig.get().quickLookupTime();
					float angles = lexiconLookupTime / requiredTime * 360F;

					IClientXplatAbstractions.INSTANCE.submitGuiElement(graphics, new TooltipRenderState(cx, cy, angles, r));

					if (lexiconLookupTime >= requiredTime) {
						mc.field_1724.method_31548().method_61496(lexSlot);
						int spread = lexiconEntry.getSecond();
						ClientBookRegistry.INSTANCE.displayBookGui(lexiconEntry.getFirst().getBook().id, lexiconEntry.getFirst().getId(), spread * 2);
					}
				} else {
					lexiconLookupTime = 0F;
				}

				graphics.method_51448().pushMatrix();
				graphics.method_51427(lexiconStack, x, tooltipY);
				graphics.method_51431(mc.field_1772, lexiconStack, x, tooltipY);
				graphics.method_51448().popMatrix();

				graphics.method_51448().pushMatrix();
				graphics.method_51433(mc.field_1772, "?", x + 10, tooltipY + 8, 0xFFFFFFFF, true);

				graphics.method_51448().scale(0.5F, 0.5F);
				boolean mac = class_156.method_668() == class_156.class_158.field_1137;
				class_2561 key = class_2561.method_43470(PatchouliConfig.get().useShiftForQuickLookup() ? "Shift" : mac ? "Cmd" : "Ctrl")
						.method_27692(class_124.field_1067);
				graphics.method_51439(mc.field_1772, key, (x + 10) * 2 - 16, (tooltipY + 8) * 2 + 20, 0xFFFFFFFF, true);
				graphics.method_51448().popMatrix();
			} else {
				lexiconLookupTime = 0F;
			}
		} else {
			lexiconLookupTime = 0F;
		}
	}

	private static class TooltipRenderState implements class_11244 {
		private final RenderPipeline pipeline;
		private final class_11231 textureSetup;
		private final int cx;
		private final int cy;
		private final float angles;
		private final float r;

		public TooltipRenderState(int cx, int cy, float angles, float r) {
			this.cx = cx;
			this.cy = cy;
			this.angles = angles;
			this.r = r;
			pipeline = RenderPipeline.builder()
					.withBlend(BlendFunction.TRANSLUCENT)
					.build();
			textureSetup = class_11231.method_70899();
		}

		@Override
		public void method_70917(class_4588 buf) {
			float a = 0.5F + 0.2F * ((float) Math.cos(ClientTicker.total / 10) * 0.5F + 0.5F);
			buf.method_22912(cx, cy, 0).method_22915(0F, 0.5F, 0F, a);

			for (float i = angles; i > 0; i--) {
				double rad = (i - 90) / 180F * Math.PI;
				buf.method_22912((float) (cx + Math.cos(rad) * r), (float) (cy + Math.sin(rad) * r), 0).method_22915(0F, 1F, 0F, 1F);
			}

			buf.method_22912(cx, cy, 0).method_22915(0F, 1F, 0F, 0F);
		}

		@Override
		public RenderPipeline comp_4055() {
			return pipeline;
		}

		@Override
		public class_11231 comp_4056() {
			return textureSetup;
		}

		@Override
		public @Nullable class_8030 comp_4069() {
			return null;
		}

		@Override
		public @Nullable class_8030 comp_4274() {
			return null;
		}
	}
}
