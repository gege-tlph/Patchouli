package vazkii.patchouli.client.book.page;

import com.google.gson.annotations.SerializedName;
import org.joml.Quaternionf;
import org.joml.Vector2f;
import org.joml.Vector3f;

import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.book.BookContentsBuilder;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.book.gui.GuiBook;
import vazkii.patchouli.client.book.gui.GuiBookEntry;
import vazkii.patchouli.client.book.page.abstr.PageWithText;
import vazkii.patchouli.common.util.EntityUtil;

import java.util.function.Function;
import net.minecraft.class_10017;
import net.minecraft.class_1074;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_898;

public class PageEntity extends PageWithText {

	@SerializedName("entity") public String entityId;

	float scale = 1F;
	@SerializedName("offset") float extraOffset = 0F;
	String name;

	boolean rotate = true;
	@SerializedName("default_rotation") float defaultRotation = -45f;

	transient boolean errored;
	transient class_1297 entity;
	transient Function<class_1937, class_1297> creator;
	transient float renderScale, offset;

	@Override
	public void build(class_1937 level, BookEntry entry, BookContentsBuilder builder, int pageNum) {
		super.build(level, entry, builder, pageNum);

		creator = EntityUtil.loadEntity(entityId);
	}

	@Override
	public void onDisplayed(GuiBookEntry parent, int left, int top) {
		super.onDisplayed(parent, left, top);

		loadEntity(parent.getMinecraft().field_1687);
	}

	@Override
	public int getTextHeight() {
		return 115;
	}

	@Override
	public void render(class_332 graphics, int mouseX, int mouseY, float pticks) {
		int x = GuiBook.PAGE_WIDTH / 2 - 53;
		int y = 7;
		GuiBook.drawFromTexture(graphics, book, x, y, 405, 149, 106, 106);

		if (name == null || name.isEmpty()) {
			if (entity != null) {
				parent.drawCenteredStringNoShadow(graphics, entity.method_5477().method_30937(), GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
			}
		} else {
			parent.drawCenteredStringNoShadow(graphics, name, GuiBook.PAGE_WIDTH / 2, 0, book.headerColor);
		}

		if (errored) {
			graphics.method_51433(fontRenderer, class_1074.method_4662("patchouli.gui.lexicon.loading_error"), 58, 60, 0xFF0000, true);
		}

		if (entity != null) {
			float rotation = rotate ? ClientTicker.total : defaultRotation;
			graphics.method_51448().pushMatrix();
			graphics.method_51448().translate(x, y);
			renderEntity(graphics, entity, 58, 60, 106, 106, rotation, renderScale * parent.getScaleFactor(), offset, pticks);
			graphics.method_51448().popMatrix();
		}

		super.render(graphics, mouseX, mouseY, pticks);
	}

	public static void renderEntity(class_332 graphics, class_1297 entity, int x, int y, int width, int height, float rotation, float renderScale, float offset, float pticks) {
		Vector2f position = graphics.method_51448().transformPosition(x, y, new Vector2f());

		int posX = Math.round(position.x);
		int posY = Math.round(position.y);

		class_898 entityrenderdispatcher = class_310.method_1551().method_1561();
		class_897<? super class_1297, ?> entityrenderer = entityrenderdispatcher.method_3953(entity);
		class_10017 entityrenderstate = entityrenderer.method_62425(entity, pticks);
		entityrenderstate.field_61820 = 0xf000f0;
		entityrenderstate.field_61823.clear();
		entityrenderstate.field_61821 = 0;

		Quaternionf rot = class_7833.field_40718.rotationDegrees(180).mul(class_7833.field_40716.rotationDegrees(rotation));
		int startX = posX - width;
		int startY = posY - height;
		int endX = posX + width;
		int endY = posY + height;
		graphics.method_44379(3, 2, width - 3, height - 3);
		graphics.method_70856(entityrenderstate, renderScale, new Vector3f(-0.1f, offset, 0f), rot, new Quaternionf(), startX, startY, endX, endY);
		graphics.method_44380();
	}

	private void loadEntity(class_1937 world) {
		if (!errored && (entity == null || !entity.method_5805() || entity.method_73183() != world)) {
			try {
				entity = creator.apply(world);

				float width = entity.method_17681();
				float height = entity.method_17682();

				float entitySize = Math.max(1F, Math.max(width, height));

				renderScale = 100F / entitySize * 0.8F * scale;
				offset = Math.max(height, entitySize) * 0.5F + extraOffset;
			} catch (Exception e) {
				errored = true;
				PatchouliAPI.LOGGER.error("Failed to load entity", e);
			}
		}
	}

}
