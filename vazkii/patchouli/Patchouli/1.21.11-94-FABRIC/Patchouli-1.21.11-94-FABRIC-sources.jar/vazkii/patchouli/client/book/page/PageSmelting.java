package vazkii.patchouli.client.book.page;

import net.minecraft.class_10294;
import net.minecraft.class_10302;
import net.minecraft.class_3861;
import net.minecraft.class_3956;
import vazkii.patchouli.client.book.page.abstr.PageSimpleProcessingRecipe;

public class PageSmelting extends PageSimpleProcessingRecipe<class_3861, class_10294> {

	public PageSmelting() {
		super(class_3956.field_17546, class_10294.class);
	}

	@Override
	protected class_10302 getIngredient(class_10294 display) {
		return display.comp_3256();
	}
}
