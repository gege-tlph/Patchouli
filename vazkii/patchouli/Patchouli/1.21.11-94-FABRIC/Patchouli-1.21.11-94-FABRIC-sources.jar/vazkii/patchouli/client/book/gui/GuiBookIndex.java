package vazkii.patchouli.client.book.gui;

import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.common.book.Book;

import java.util.Collection;
import net.minecraft.class_1074;
import net.minecraft.class_2561;

public class GuiBookIndex extends GuiBookEntryList {

	public GuiBookIndex(Book book) {
		super(book, class_2561.method_43471("patchouli.gui.lexicon.index"));
	}

	@Override
	protected String getDescriptionText() {
		return class_1074.method_4662("patchouli.gui.lexicon.index.info");
	}

	@Override
	protected Collection<BookEntry> getEntries() {
		return book.getContents().entries.values();
	}

}
