package vazkii.patchouli.client.book.template.test;

import vazkii.patchouli.api.IComponentRenderContext;
import vazkii.patchouli.api.ICustomComponent;
import vazkii.patchouli.api.IVariable;
import vazkii.patchouli.api.PatchouliAPI;

import java.util.function.UnaryOperator;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7225;

public class ComponentCustomTest implements ICustomComponent {
	private transient int x, y;
	private transient String text = "";

	@Override
	public void build(int componentX, int componentY, int pageNum) {
		x = componentX;
		y = componentY;
		PatchouliAPI.LOGGER.debug("Custom Component Test built at ({}, {}) page {}", componentX, componentY, pageNum);
	}

	@Override
	public void render(class_332 graphics, IComponentRenderContext context, float pticks, int mouseX, int mouseY) {
		class_2561 toRender = class_2561.method_43470(text).method_10862(context.getFontStyle());
		graphics.method_51439(class_310.method_1551().field_1772, toRender, x, y, -1, true);
	}

	@Override
	public boolean mouseClicked(IComponentRenderContext context, class_11909 event, boolean doubleClick) {
		PatchouliAPI.LOGGER.debug("Custom Component Test clicked {}", event);
		return false;
	}

	@Override
	public void onVariablesAvailable(UnaryOperator<IVariable> lookup, class_7225.class_7874 registries) {
		text = lookup.apply(IVariable.wrap("First we eat #spaghet#, then we drink #pop#", registries)).asString();
	}
}
