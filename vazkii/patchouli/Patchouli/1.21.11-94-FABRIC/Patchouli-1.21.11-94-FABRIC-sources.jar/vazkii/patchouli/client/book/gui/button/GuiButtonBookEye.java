package vazkii.patchouli.client.book.gui.button;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.base.PersistentData;
import vazkii.patchouli.client.book.gui.GuiBook;

public class GuiButtonBookEye extends GuiButtonBook {

	public GuiButtonBookEye(GuiBook parent, int x, int y, class_4185.class_4241 onPress) {
		super(parent, x, y, 308, 31, 11, 11, onPress,
				class_2561.method_43471("patchouli.gui.lexicon.button.visualize"),
				class_2561.method_43471("patchouli.gui.lexicon.button.visualize.info").method_27692(class_124.field_1080));
	}

	@Override
	protected void method_75752(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_75752(graphics, mouseX, mouseY, partialTicks);

		if (!PersistentData.data.clickedVisualize && (ClientTicker.ticksInGame) % 20 < 10) {
			graphics.method_51433(parent.getMinecraft().field_1772, "!", method_46426(), method_46427(), 0xFF3333, true);
		}
	}
}
