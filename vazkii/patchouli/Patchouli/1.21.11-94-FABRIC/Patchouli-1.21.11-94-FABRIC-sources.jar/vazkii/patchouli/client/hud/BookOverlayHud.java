package vazkii.patchouli.client.hud;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1041;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.book.BookEntry;
import vazkii.patchouli.client.handler.BookRightClickHandler;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.util.ItemStackUtil;

public final class BookOverlayHud {
	public static final class_2960 ID = class_2960.method_60655(PatchouliAPI.MOD_ID, "book_overlay");

	private BookOverlayHud() {}

	public static void render(class_332 graphics, class_9779 deltaTracker) {
		class_310 mc = class_310.method_1551();
		class_1657 player = mc.field_1724;
		class_1799 bookStack = player.method_6047();
		if (mc.field_1755 == null) {
			Book book = ItemStackUtil.getBookFromStack(bookStack);

			if (book != null) {
				Pair<BookEntry, Integer> hover = BookRightClickHandler.getHoveredEntry(book);
				if (hover != null) {
					BookEntry entry = hover.getFirst();
					if (!entry.isLocked()) {
						class_1041 window = mc.method_22683();
						int x = window.method_4486() / 2 + 3;
						int y = window.method_4502() / 2 + 3;
						entry.getIcon().render(graphics, x, y);

						graphics.method_51448().pushMatrix();
						graphics.method_51448().scale(0.5F, 0.5F);
						graphics.method_51427(bookStack, (x + 8) * 2, (y + 8) * 2);
						graphics.method_51431(mc.field_1772, bookStack, (x + 8) * 2, (y + 8) * 2);
						graphics.method_51448().popMatrix();

						graphics.method_51439(mc.field_1772, entry.getName(), x + 18, y + 3, 0xFFFFFF, false);

						graphics.method_51448().pushMatrix();
						graphics.method_51448().scale(0.75F, 0.75F);
						class_2561 s = class_2561.method_43471("patchouli.gui.lexicon." + (player.method_5715() ? "view" : "sneak"))
								.method_27692(class_124.field_1056);
						graphics.method_51439(mc.field_1772, s, (int) ((x + 18) / 0.75F), (int) ((y + 14) / 0.75F), 0xBBBBBB, false);
						graphics.method_51448().popMatrix();
					}
				}
			}
		}
	}
}
