package vazkii.patchouli.client.handler;

import com.mojang.datafixers.util.Pair;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import org.joml.Matrix4f;

import vazkii.patchouli.api.IMultiblock;
import vazkii.patchouli.client.base.ClientTicker;
import vazkii.patchouli.client.base.PersistentData.Bookmark;
import vazkii.patchouli.common.multiblock.StateMatcher;
import vazkii.patchouli.common.util.RotationUtil;
import vazkii.patchouli.mixin.client.AccessorMultiBufferSource;

import java.util.Collection;
import java.util.Map;
import java.util.SequencedMap;
import java.util.function.Function;
import net.minecraft.class_1109;
import net.minecraft.class_12249;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_777;
import net.minecraft.class_898;
import net.minecraft.class_9799;

public final class MultiblockVisualizationHandler {
	public static final MultiblockVisualizationHandler INSTANCE = new MultiblockVisualizationHandler();

	private boolean hasMultiblock;
	private Bookmark bookmark;
	private IMultiblock multiblock;
	private class_2561 name;
	private class_2338 pos;
	private boolean isAnchored;
	private class_2470 facingRotation;
	private Function<class_2338, class_2338> offsetApplier;
	private int blocks, blocksDone, airFilled;
	private int timeComplete;
	private class_2680 lookingState;
	private class_2338 lookingPos;
	private GhostBuffers buffers = null;

	public boolean hasMultiblock() {
		return hasMultiblock;
	}

	public void setHasMultiblock(boolean hasMultiblock) {
		this.hasMultiblock = hasMultiblock;
	}

	public Bookmark bookmark() {
		return bookmark;
	}

	public class_2561 name() {
		return name;
	}

	public class_2680 getLookingState() {
		return lookingState;
	}

	public class_2338 getLookingPos() {
		return lookingPos;
	}

	public int getTimeComplete() {
		return timeComplete;
	}

	public float getProgress() {
		return (float) blocksDone / Math.max(1, blocks);
	}

	public String getProgressString() {
		return blocksDone + "/" + blocks;
	}

	public boolean isComplete() {
		return blocksDone == blocks && airFilled > 0;
	}

	public void setMultiblock(IMultiblock multiblock, class_2561 name, Bookmark bookmark, boolean flip) {
		setMultiblock(multiblock, name, bookmark, flip, pos -> pos);
	}

	public void setMultiblock(IMultiblock multiblock, class_2561 name, Bookmark bookmark, boolean flip, Function<class_2338, class_2338> offsetApplier) {
		if (flip && hasMultiblock) {
			hasMultiblock = false;
		} else {
			this.multiblock = multiblock;
			this.name = name;
			this.bookmark = bookmark;
			this.offsetApplier = offsetApplier;
			pos = null;
			hasMultiblock = multiblock != null;
			isAnchored = false;
		}
	}

	public void onWorldRenderLast(class_4587 ms, Matrix4f pose) {
		if (hasMultiblock && multiblock != null) {
			renderMultiblock(class_310.method_1551().field_1687, ms, pose);
		}
	}

	public void anchorTo(class_2338 target, class_2470 rot) {
		pos = target;
		facingRotation = rot;
		isAnchored = true;
	}

	public class_1269 onPlayerInteract(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
		if (hasMultiblock && !isAnchored && player == class_310.method_1551().field_1724) {
			anchorTo(hit.method_17777(), getRotation(player));
			return class_1269.field_5812;
		}
		return class_1269.field_5811;
	}

	public void onClientTick(class_310 mc) {
		if (class_310.method_1551().field_1687 == null) {
			hasMultiblock = false;
		} else if (isAnchored && blocks == blocksDone && airFilled == 0) {
			timeComplete++;
			if (timeComplete == 14) {
				class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_14627, 1.0F));
			}
		} else {
			timeComplete = 0;
		}
	}

	public void renderMultiblock(class_1937 world, class_4587 ms, Matrix4f pose) {
		ms.method_34425(pose);
		class_310 mc = class_310.method_1551();
		if (!isAnchored) {
			facingRotation = getRotation(mc.field_1724);
			if (mc.field_1765 instanceof class_3965) {
				pos = ((class_3965) mc.field_1765).method_17777();
			}
		} else if (pos.method_19770(mc.field_1724.method_73189()) > 64 * 64) {
			return;
		}

		if (pos == null) {
			return;
		}
		if (multiblock.isSymmetrical()) {
			facingRotation = class_2470.field_11467;
		}

		class_898 erd = mc.method_1561();
		double renderPosX = erd.field_4686.method_71156().method_10216();
		double renderPosY = erd.field_4686.method_71156().method_10214();
		double renderPosZ = erd.field_4686.method_71156().method_10215();
		ms.method_22903();
		ms.method_22904(-renderPosX, -renderPosY, -renderPosZ);

		if (buffers == null) {
			buffers = initBuffers(mc.method_22940().method_23000());
		}

		class_2338 checkPos = null;
		if (mc.field_1765 instanceof class_3965 blockRes) {
			checkPos = blockRes.method_17777().method_10093(blockRes.method_17780());
		}

		blocks = blocksDone = airFilled = 0;
		lookingState = null;
		lookingPos = checkPos;

		Pair<class_2338, Collection<IMultiblock.SimulateResult>> sim = multiblock.simulate(world, getStartPos(), getFacingRotation(), true);
		for (IMultiblock.SimulateResult r : sim.getSecond()) {
			float alpha = 0.3F;
			if (r.getWorldPosition().equals(checkPos)) {
				lookingState = r.getStateMatcher().getDisplayedState(ClientTicker.ticksInGame);
				alpha = 0.6F + (float) (Math.sin(ClientTicker.total * 0.3F) + 1F) * 0.1F;
			}

			if (r.getStateMatcher() != StateMatcher.ANY) {
				boolean air = r.getStateMatcher() == StateMatcher.AIR;
				if (!air) {
					blocks++;
				}

				if (!r.test(world, facingRotation)) {
					class_2680 renderState = r.getStateMatcher().getDisplayedState(ClientTicker.ticksInGame).method_26186(facingRotation);
					renderBlock(world, renderState, r.getWorldPosition(), alpha, ms);

					if (air) {
						airFilled++;
					}
				} else if (!air) {
					blocksDone++;
				}
			}
		}

		buffers.method_22993();
		ms.method_22909();

		if (!isAnchored) {
			blocks = blocksDone = 0;
		}
	}

	public void renderBlock(class_1937 world, class_2680 state, class_2338 pos, float alpha, class_4587 ms) {
		if (pos != null) {
			ms.method_22903();
			ms.method_46416(pos.method_10263(), pos.method_10264(), pos.method_10260());

			if (state.method_26204() == class_2246.field_10124) {
				float scale = 0.3F;
				float off = (1F - scale) / 2;
				ms.method_46416(off, off, -off);
				ms.method_22905(scale, scale, scale);

				state = class_2246.field_10058.method_9564();
			}

			buffers.setAlpha(alpha);
			class_310.method_1551().method_1541().method_3353(state, ms, buffers, 0xF000F0, class_4608.field_21444);

			ms.method_22909();
		}
	}

	public IMultiblock getMultiblock() {
		return multiblock;
	}

	public boolean isAnchored() {
		return isAnchored;
	}

	public class_2470 getFacingRotation() {
		return multiblock.isSymmetrical() ? class_2470.field_11467 : facingRotation;
	}

	public class_2338 getStartPos() {
		return offsetApplier.apply(pos);
	}

	/**
	 * Returns the Rotation of a multiblock structure based on the given entity's facing direction.
	 */
	private class_2470 getRotation(class_1297 entity) {
		return RotationUtil.rotationFromFacing(entity.method_5735());
	}

	private GhostBuffers initBuffers(class_4597.class_4598 original) {
		class_9799 fallback = ((AccessorMultiBufferSource) original).getFallbackBuffer();
		SequencedMap<class_1921, class_9799> layerBuffers = ((AccessorMultiBufferSource) original).getFixedBuffers();
		SequencedMap<class_1921, class_9799> remapped = new Object2ObjectLinkedOpenHashMap<>();
		for (Map.Entry<class_1921, class_9799> e : layerBuffers.entrySet()) {
			remapped.put(e.getKey(), e.getValue());
		}
		return new GhostBuffers(fallback, remapped);
	}

	private static class GhostBuffers extends class_4597.class_4598 {
		private float alpha = 1F;

		protected GhostBuffers(class_9799 fallback, SequencedMap<class_1921, class_9799> layerBuffers) {
			super(fallback, layerBuffers);
		}

		private void setAlpha(float alpha) {
			this.alpha = alpha;
		}

		@Override
		public class_4588 method_73477(class_1921 type) {
			// All ghost geometry is drawn through the translucent moving-block layer so the
			// preview can blend; the per-quad alpha is forced by GhostAlphaVertexConsumer.
			return new GhostAlphaVertexConsumer(super.method_73477(class_12249.method_75977()), alpha);
		}
	}

	private record GhostAlphaVertexConsumer(class_4588 prior, float alpha) implements class_4588 {
		@Override
		public class_4588 method_22912(float x, float y, float z) {
			return prior.method_22912(x, y, z);
		}

		@Override
		public class_4588 method_1336(int r, int g, int b, int a) {
			return prior.method_1336(r, g, b, a);
		}

		@Override
		public class_4588 method_39415(int color) {
			return prior.method_39415(color);
		}

		@Override
		public class_4588 method_22913(float u, float v) {
			return prior.method_22913(u, v);
		}

		@Override
		public class_4588 method_60796(int u, int v) {
			return prior.method_60796(u, v);
		}

		@Override
		public class_4588 method_22921(int u, int v) {
			return prior.method_22921(u, v);
		}

		@Override
		public class_4588 method_22914(float x, float y, float z) {
			return prior.method_22914(x, y, z);
		}

		@Override
		public class_4588 method_75298(float width) {
			return prior.method_75298(width);
		}

		@Override
		public void method_22919(class_4587.class_4665 pose, class_777 quad, float r, float g, float b, float a, int light, int overlay) {
			prior.method_22919(pose, quad, r, g, b, alpha, light, overlay);
		}

		@Override
		public void method_22920(class_4587.class_4665 pose, class_777 quad, float[] brightness, float r, float g, float b, float a, int[] lights, int overlay) {
			prior.method_22920(pose, quad, brightness, r, g, b, alpha, lights, overlay);
		}
	}
}
