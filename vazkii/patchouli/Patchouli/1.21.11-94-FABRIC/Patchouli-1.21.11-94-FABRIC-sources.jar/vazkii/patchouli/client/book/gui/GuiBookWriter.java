package vazkii.patchouli.client.book.gui;

import net.minecraft.class_1074;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import org.jspecify.annotations.Nullable;

import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.client.book.gui.button.GuiButtonBook;
import vazkii.patchouli.common.book.Book;

public class GuiBookWriter extends GuiBook {

	private @Nullable BookTextRenderer text, editableText;
	private @Nullable class_342 textfield;

	private static String savedText = "";
	private static boolean drawHeader;

	public GuiBookWriter(Book book) {
		super(book, class_2561.method_43473());
	}

	@Override
	public void method_25426() {
		super.method_25426();

		this.text = method_37060(new BookTextRenderer(this, class_2561.method_43471("patchouli.gui.lexicon.editor.info"), LEFT_PAGE_X, TOP_PADDING + 20));
		this.textfield = method_37063(new class_342(field_22793, 15, FULL_HEIGHT - 40, PAGE_WIDTH, 20, textfield, class_2561.method_43473()));
		this.textfield.method_1880(Integer.MAX_VALUE);
		if (this.textfield.method_1882().isEmpty()) {
			this.textfield.method_1852(savedText);
		}
		this.editableText = method_37060(new BookTextRenderer(this, class_2561.method_43470(""), RIGHT_PAGE_X, TOP_PADDING + (drawHeader ? 22 : -4)));

		method_37063(new GuiButtonBook(this, bookLeft + 115, bookTop + PAGE_HEIGHT - 36, 330, 9, 11, 11, this::handleToggleHeaderButton, class_2561.method_43471("patchouli.gui.lexicon.button.toggle_mock_header")));
		refreshText();
	}

	@Override
	void drawForegroundElements(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.drawForegroundElements(graphics, mouseX, mouseY, partialTicks);

		drawCenteredStringNoShadow(graphics, class_1074.method_4662("patchouli.gui.lexicon.editor"), LEFT_PAGE_X + PAGE_WIDTH / 2, TOP_PADDING, book.headerColor);
		drawSeparator(graphics, book, LEFT_PAGE_X, TOP_PADDING + 12);

		if (drawHeader) {
			drawCenteredStringNoShadow(graphics, class_1074.method_4662("patchouli.gui.lexicon.editor.mock_header"), RIGHT_PAGE_X + PAGE_WIDTH / 2, TOP_PADDING, book.headerColor);
			drawSeparator(graphics, book, RIGHT_PAGE_X, TOP_PADDING + 12);
		}
	}

	@Override
	public boolean mouseClickedScaled(class_11909 event, boolean doubleClick) {
		if (textfield != null && textfield.method_25402(new class_11909(getRelativeX(event.comp_4798()), getRelativeY(event.comp_4799()), event.comp_4800()), doubleClick)) {
			textfield.method_25365(true);
			return true;
		}
		if (text != null && text.click(event, doubleClick)) {
			return true;
		}
		if (editableText != null && editableText.click(event, doubleClick)) {
			return true;
		}
		return super.mouseClickedScaled(event, doubleClick);
	}

	@Override
	public boolean method_25404(class_11908 event) {
		if (textfield != null && textfield.method_25404(event)) {
			refreshText();
			return true;
		}

		return super.method_25404(event);
	}

	@Override
	public boolean method_25400(class_11905 event) {
		if (textfield != null && textfield.method_25400(event)) {
			refreshText();
			return true;
		}

		return super.method_25400(event);
	}

	private void handleToggleHeaderButton(class_4185 button) {
		drawHeader = !drawHeader;
		method_25426();
	}

	private void refreshText() {
		assert textfield != null;
		assert editableText != null;
		savedText = textfield.method_1882();
		try {
			editableText.setText(class_2561.method_43470(savedText));
		} catch (Throwable e) {
			editableText.setText(class_2561.method_43470("[ERROR]"));
			PatchouliAPI.LOGGER.catching(e);
		}
	}
}
