package vazkii.patchouli.client.book;

import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import vazkii.patchouli.api.PatchouliAPI;
import vazkii.patchouli.common.util.ItemStackUtil;

public sealed interface BookIcon permits BookIcon.StackIcon, BookIcon.TextureIcon {
	void render(class_332 graphics, int x, int y);

	record StackIcon(class_1799 stack) implements BookIcon {
		@Override
		public void render(class_332 graphics, int x, int y) {
			graphics.method_51427(stack(), x, y);
			graphics.method_51431(class_310.method_1551().field_1772, stack(), x, y);
		}
	}

	record TextureIcon(class_2960 texture) implements BookIcon {
		@Override
		public void render(class_332 graphics, int x, int y) {
			graphics.method_52706(class_10799.field_56883, texture(), x, y, 16, 16);
		}
	}

	static BookIcon from(String str, class_7225.class_7874 registries) {
		if (str.endsWith(".png")) {
			return new TextureIcon(class_2960.method_12829(str));
		} else {
			try {
				class_1799 stack = ItemStackUtil.loadStackFromString(str, registries);
				return new StackIcon(stack);
			} catch (Exception e) {
				PatchouliAPI.LOGGER.warn("Invalid icon item stack: {}", e.getMessage());
				return new StackIcon(class_1799.field_8037);
			}
		}
	}

}
