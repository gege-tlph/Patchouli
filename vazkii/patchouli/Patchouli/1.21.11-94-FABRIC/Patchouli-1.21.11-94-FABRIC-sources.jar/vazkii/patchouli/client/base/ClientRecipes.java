package vazkii.patchouli.client.base;

import vazkii.patchouli.client.book.ClientBookRegistry;

import org.jetbrains.annotations.Nullable;

import java.util.*;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8786;

public final class ClientRecipes {
	public static final ClientRecipes INSTANCE = new ClientRecipes();

	private final Map<class_3956<?>, Collection<class_8786<?>>> recipesByType = new HashMap<>();
	private final Map<class_5321<class_1860<?>>, class_8786<?>> recipesById = new HashMap<>();

	private ClientRecipes() {}

	public void receivedRecipes(Collection<class_8786<?>> recipes) {
		recipesByType.clear();
		recipesById.clear();
		for (class_8786<?> recipe : recipes) {
			recipesByType.computeIfAbsent(recipe.comp_1933().method_17716(), rt -> new java.util.ArrayList<>()).add(recipe);
			recipesById.put(recipe.comp_1932(), recipe);
		}
		// Books are built when the first advancement packet arrives. If that already
		// happened, they were built without recipes and need a rebuild; if not, the
		// upcoming advancement-triggered build will see the cache filled here.
		if (ClientAdvancements.hasReceivedFirstAdvPacket()) {
			ClientBookRegistry.INSTANCE.reload();
		}
	}

	@SuppressWarnings("unchecked")
	public <R extends class_1860<?>> @Nullable class_8786<R> getRecipeById(class_5321<class_1860<?>> key) {
		class_8786<?> holder = recipesById.get(key);
		if (holder == null) {
			return null;
		}
		return (class_8786<R>) holder;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public <T extends class_1860<?>> Collection<class_8786<? extends T>> getRecipesByType(class_3956<T> type) {
		return (Collection<class_8786<? extends T>>) (Collection) recipesByType.getOrDefault(type, List.of());
	}

	public <R extends class_1860<?>> @Nullable class_8786<R> getRecipeById(class_2960 id) {
		return getRecipeById(class_5321.method_29179(class_7924.field_52178, id));
	}
}
