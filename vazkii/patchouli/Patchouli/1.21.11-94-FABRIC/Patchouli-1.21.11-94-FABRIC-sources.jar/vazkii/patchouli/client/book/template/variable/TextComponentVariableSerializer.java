package vazkii.patchouli.client.book.template.variable;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_2561;
import net.minecraft.class_7225;
import net.minecraft.class_8824;
import vazkii.patchouli.api.IVariableSerializer;

public class TextComponentVariableSerializer implements IVariableSerializer<class_2561> {
	@Override
	public class_2561 fromJson(JsonElement json, class_7225.class_7874 registries) {
		if (json.isJsonNull()) {
			return class_2561.method_43470("");
		}
		if (json.isJsonPrimitive()) {
			return class_2561.method_43470(json.getAsString());
		}
		return class_8824.field_46597.parse(registries.method_57093(JsonOps.INSTANCE), json).getOrThrow();
	}

	@Override
	public JsonElement toJson(class_2561 stack, class_7225.class_7874 registries) {
		return class_8824.field_46597.encodeStart(registries.method_57093(JsonOps.INSTANCE), stack).getOrThrow(JsonParseException::new);
	}
}
