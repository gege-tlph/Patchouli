package vazkii.patchouli.client.book.page;

import net.minecraft.class_10302;
import net.minecraft.class_10315;
import net.minecraft.class_3956;
import net.minecraft.class_3975;
import vazkii.patchouli.client.book.page.abstr.PageSimpleProcessingRecipe;

public class PageStonecutting extends PageSimpleProcessingRecipe<class_3975, class_10315> {

	public PageStonecutting() {
		super(class_3956.field_17641, class_10315.class);
	}

	@Override
	protected class_10302 getIngredient(class_10315 display) {
		return display.comp_3305();
	}
}
