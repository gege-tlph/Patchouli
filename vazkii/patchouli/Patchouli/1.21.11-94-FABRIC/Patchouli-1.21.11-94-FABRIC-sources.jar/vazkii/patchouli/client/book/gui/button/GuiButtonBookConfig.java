package vazkii.patchouli.client.book.gui.button;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import vazkii.patchouli.client.book.gui.GuiBook;

public class GuiButtonBookConfig extends GuiButtonBook {

	public GuiButtonBookConfig(GuiBook parent, int x, int y, class_4185.class_4241 onPress) {
		super(parent, x, y, 308, 20, 11, 11, onPress,
				class_2561.method_43471("patchouli.gui.lexicon.button.config"));
	}

}
