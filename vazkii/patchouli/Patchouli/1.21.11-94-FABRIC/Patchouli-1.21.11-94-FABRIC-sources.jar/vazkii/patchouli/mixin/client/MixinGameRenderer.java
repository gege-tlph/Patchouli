package vazkii.patchouli.mixin.client;

import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.base.ClientTicker;

@Mixin(class_757.class)
public class MixinGameRenderer {
	@Inject(at = @At("HEAD"), method = "render(Lnet/minecraft/client/DeltaTracker;Z)V")
	public void patchouli_renderStart(class_9779 deltaTracker, boolean tick, CallbackInfo info) {
		ClientTicker.renderTickStart(deltaTracker.method_60637(false));
	}

	@Inject(at = @At("RETURN"), method = "render(Lnet/minecraft/client/DeltaTracker;Z)V")
	public void patchouli_renderEnd(class_9779 deltaTracker, boolean tick, CallbackInfo info) {
		ClientTicker.renderTickEnd();
	}

}
