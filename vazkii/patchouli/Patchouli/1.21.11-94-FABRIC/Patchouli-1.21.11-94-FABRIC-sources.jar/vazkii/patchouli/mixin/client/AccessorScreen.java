package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public interface AccessorScreen {

	@Accessor("renderables")
	List<class_4068> getRenderables();

	@Accessor("narratables")
	List<class_6379> getNarratables();
}
