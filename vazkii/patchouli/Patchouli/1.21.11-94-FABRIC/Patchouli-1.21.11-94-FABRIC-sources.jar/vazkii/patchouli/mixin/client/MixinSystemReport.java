package vazkii.patchouli.mixin.client;

import net.minecraft.class_6396;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.handler.BookCrashHandler;

@Mixin(class_6396.class)
public class MixinSystemReport {
	@Inject(at = @At("RETURN"), method = "<init>")
	private void patchouli_addContext(CallbackInfo ci) {
		BookCrashHandler.appendToCrashReport((class_6396) (Object) this);
	}
}
