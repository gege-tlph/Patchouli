package vazkii.patchouli.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.base.ClientAdvancements;

@Mixin(class_310.class)
public class MixinMinecraft {
	@Inject(at = @At("HEAD"), method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;ZZ)V")
	public void patchouli_onLogout(class_437 screen, boolean keepResourcePacks, boolean showDisconnectScreen, CallbackInfo info) {
		ClientAdvancements.playerLogout();
	}

}
