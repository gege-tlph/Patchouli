package vazkii.patchouli.mixin.client;

import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.handler.TooltipHandler;

@Mixin(class_332.class)
public class MixinGuiGraphics {
	@Inject(at = @At("HEAD"), method = "setTooltipForNextFrame(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;II)V")
	public void patchouli_onRenderTooltip(class_327 font, class_1799 stack, int x, int y, CallbackInfo info) {
		TooltipHandler.onTooltip((class_332) (Object) this, stack, x, y);
	}
}
