package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_304;

@Mixin(class_304.class)
public interface AccessorKeyMapping {
	@Accessor("ALL")
	static Map<String, class_304> getAllKeyMappings() {
		throw new IllegalStateException();
	}
}
