package vazkii.patchouli.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.gui.GuiButtonInventoryBook;
import vazkii.patchouli.common.base.PatchouliConfig;
import vazkii.patchouli.common.book.Book;
import vazkii.patchouli.common.book.BookRegistry;

import java.util.List;
import net.minecraft.class_10260;
import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_344;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_490;
import net.minecraft.class_507;

@Mixin(class_490.class)
public abstract class MixinInventoryScreen extends class_10260<class_1723> {
	public MixinInventoryScreen(class_1723 menu, class_507<?> recipeBookComponent, class_1661 playerInventory, class_2561 title) {
		super(menu, recipeBookComponent, playerInventory, title);
	}

	@Inject(at = @At("RETURN"), method = "init()V")
	public void onGuiInitPost(CallbackInfo info) {
		var bookID = class_2960.method_12829(PatchouliConfig.get().inventoryButtonBook());
		Book book = BookRegistry.INSTANCE.books.get(bookID);
		if (book == null) {
			return;
		}

		class_4068 replaced = null;
		class_4185 replacement = null;
		for (int i = 0; i < ((AccessorScreen) this).getRenderables().size(); i++) {
			class_4068 button = ((AccessorScreen) this).getRenderables().get(i);
			if (button instanceof class_344 tex) {
				replaced = button;
				replacement = new GuiButtonInventoryBook(book, tex.method_46426(), tex.method_46427() - 1);
				((AccessorScreen) this).getRenderables().set(i, replacement);
				break;
			}
		}

		int i = method_25396().indexOf(replaced);
		if (i >= 0) {
			((List<class_364>) method_25396()).set(i, replacement);
		}

		i = ((AccessorScreen) this).getNarratables().indexOf(replaced);
		if (i >= 0) {
			((AccessorScreen) this).getNarratables().set(i, replacement);
		}
	}
}
