package vazkii.patchouli.mixin.client;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import vazkii.patchouli.client.handler.MultiblockVisualizationHandler;

@Mixin(class_761.class)
public class MixinLevelRenderer {
	@Inject(at = @At("RETURN"), method = "renderLevel")
	public void onRender(class_9922 graphicsResourceAllocator, class_9779 deltaTracker, boolean renderBlockOutline, class_4184 camera, Matrix4f frustumMatrix, Matrix4f projectionMatrix, Matrix4f cullingProjectionMatrix, GpuBufferSlice shaderFog, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
		MultiblockVisualizationHandler.INSTANCE.onWorldRenderLast(new class_4587(), projectionMatrix);
	}
}
